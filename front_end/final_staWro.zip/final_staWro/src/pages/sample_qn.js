import React from 'react'

const Sample_qn = () => {
  return (
    <div>
        <div className='Home-cnt-01-sub-01'>
                <strong>sta<span>W</span>ro</strong>
                <hr/>
            </div>

            <div className='sample-page-nme-cnt-01'>
                <h2>Questions</h2>
            </div>
            <br/>

            <h2 style={{fontSize: "20px"}}>Comming Soon</h2>
    </div>
  )
}

export default Sample_qn
